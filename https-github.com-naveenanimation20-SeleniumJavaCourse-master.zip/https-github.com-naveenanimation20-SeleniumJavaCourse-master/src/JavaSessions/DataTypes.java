package JavaSessions;

//hi this is my first java code
/*hi this is
my first java code
im so happy
*/


public class DataTypes {

	public static void main(String[] args) {

		//primitive data types: int, double, char, boolean
		//data types:
		//1. int:
		int i = 10;
		 i = 20;
		 i = 30;
		 int j = 40;
		 int k = -10;
		 int p = 0;
		 System.out.println(i);
		 System.out.println(k);
		 System.out.println(i+j);
		 
		//2. double:
		 double d1 = 12.33;
		 double d2 = -12.33;
		 double d3 = 100;
		 System.out.println(d1);
		 System.out.println(d1+d2);
		 
		//3. char:
		 char c1 = 'a';
		 char c2 = '1';
		 char c3 = '$';
		 char gender = 'M';
		 
		 //4. boolean:
		 boolean b1 = true;
		 boolean b2 = false;
		 
		 //5. String: is a class in java, not a data type
		 String s1 = "Hello World";
		 String s2 = "Hey this is my java code";
		 String s3 = "100";
		 String s4 = "12.33";
		 
		 System.out.println(s2);
		 
		 System.out.println(1000);
		 System.out.println(12.45);
		 System.out.println("Hello World");
		 
		
		
		
	}

}
