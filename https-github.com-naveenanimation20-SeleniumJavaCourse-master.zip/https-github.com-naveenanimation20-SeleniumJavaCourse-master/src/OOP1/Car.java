package OOP1;

public class Car extends Truck {
	
	
	public void start(){
		System.out.println("Car--start");
	}
	
	
	public void stop(){
		System.out.println("Car--stop");
	}
	
	public void refuel(){
		System.out.println("Car--refuel");
	}
	
	
	

}
