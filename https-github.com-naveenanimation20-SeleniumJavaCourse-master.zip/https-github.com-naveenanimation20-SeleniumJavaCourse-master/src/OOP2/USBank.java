package OOP2;

public interface USBank {
	
	
	public void debit();
	
	public void credit();
	
	public void transferMoney();
	
	public void mutualFunds();
	
	

}
