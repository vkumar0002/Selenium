package OOP1;

public class Truck {
	
	public void engine(){
		System.out.println("Truck -- engine");
	}

}
